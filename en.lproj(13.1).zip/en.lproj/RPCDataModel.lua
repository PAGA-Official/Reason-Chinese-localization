-- JE: these are temporary, not exactly decided

Byte = "Byte"
Long = "Long"
Generator = "Generator"
SupportGenerator = "SupportGenerator"
MonoToStereoEffect = "MonoToStereoEffect"
DualMonoEffect = "DualMonoEffect"

Tom={
	module_type = Generator,
	properties={
			{key="Pitch", default=-6, min=-64, max=63, type=Byte},
			{key="Decay", default=118, min=0, max=127, type=Byte},
			{key="StickLevel", default=65, min=0, max=127, type=Byte},
			{key="Tune2", default=88, min=0, max=127, type=Byte},
			{key="KettleMix", default=32, min=0, max=127, type=Byte},
			{key="Tune1", default=59, min=0, max=127, type=Byte},
			{key="StickTone", default=107, min=0, max=127, type=Byte},
			{key="P1", default=67, min=0, max=127, type=Byte},
			{key="KettleSize", default=33, min=0, max=127, type=Byte},
			{key="Level", default=96, min=0, max=127, type=Byte},
			{key="BendAmt", default=38, min=0, max=127, type=Byte},
	}
}

BassDrum={
	module_type = Generator,
	properties={
			{key="Pitch", default=0, min=-64, max=63, type=Byte},
			{key="Decay", default=44, min=0, max=127, type=Byte},
			{key="ClickLevel", default=64, min=0, max=127, type=Byte},
			{key="Tune2", default=60, min=0, max=127, type=Byte},
			{key="KettleMix", default=33, min=0, max=127, type=Byte},
			{key="Tune1", default=107, min=0, max=127, type=Byte},
			{key="ClickDiffuse", default=102, min=0, max=127, type=Byte},
			{key="ClickFreq", default=75, min=0, max=127, type=Byte},
			{key="P1", default=64, min=0, max=127, type=Byte},
			{key="Level", default=100, min=0, max=127, type=Byte},
			{key="BendAmt", default=57, min=0, max=127, type=Byte},
	}
}


SnareDrum={
	module_type = Generator,
	properties={
			{key="Mix", default=70, min=0, max=127, type=Byte},
			{key="Level", default=99, min=0, max=127, type=Byte},
			{key="Snare Dist", default=3, min=0, max=127, type=Byte},
			{key="Decay", default=59, min=0, max=127, type=Byte},
			{key="Pitch", default=2, min=-64, max=63, type=Byte},
			{key="Tuning", default=62, min=0, max=127, type=Byte},
			{key="Bottom Pitch", default=64, min=0, max=127, type=Byte},
			{key="Edge Tune", default=34, min=0, max=127, type=Byte},
			{key="P1", default=59, min=0, max=127, type=Byte},
	}
}

Ambience={
	module_type = MonoToStereoEffect,
	properties={
			{key="P2", default=65, min=0, max=127, type=Byte},
			{key="P1", default=65, min=0, max=127, type=Byte},
			{key="Damp", default=65, min=0, max=127, type=Byte},
			{key="Dry/Wet", default=58, min=0, max=127, type=Byte},
			{key="Width", default=127, min=0, max=127, type=Byte},
	}
}

Resonator={
	module_type = DualMonoEffect,
	properties={
			{key="P2", default=65, min=0, max=127, type=Byte},
			{key="P1", default=66, min=0, max=127, type=Byte},
			{key="Drive", default=64, min=0, max=127, type=Byte},
			{key="Preset", default=0, min=0, max=4, type=Byte},
	}
}


SynthSnare={
	module_type = Generator,
	properties={
			{key="Level", default=99, min=0, max=127, type=Byte},
			{key="Pitch", default=-2, min=-64, max=63, type=Byte},
			{key="NoiseTone", default=90, min=0, max=127, type=Byte},
			{key="P1", default=75, min=0, max=127, type=Byte},
			{key="NoiseMix", default=41, min=0, max=127, type=Byte},
			{key="HarmFreq", default=42, min=0, max=127, type=Byte},
			{key="Decay", default=49, min=0, max=127, type=Byte},
			{key="HarmDecay", default=64, min=0, max=127, type=Byte},
			{key="HarmBalance", default=72, min=0, max=127, type=Byte},
	}
}

HiHat={
	module_type = Generator,
	properties={
			{key="Tone", default=61, min=0, max=127, type=Byte},
			{key="P1", default=73, min=0, max=127, type=Byte},
			{key="Level", default=94, min=0, max=127, type=Byte},
			{key="Pitch", default=1, min=-64, max=63, type=Byte},
			{key="Decay", default=52, min=0, max=127, type=Byte},
			{key="Click", default=66, min=0, max=127, type=Byte},
	}
}

SynthBD={
	module_type = Generator,
	properties={
			{key="Level", default=101, min=0, max=127, type=Byte},
			{key="Pitch", default=-3, min=-64, max=63, type=Byte},
			{key="BendAmt", default=35, min=0, max=127, type=Byte},
			{key="Decay", default=46, min=0, max=127, type=Byte},
			{key="Click Level", default=59, min=0, max=127, type=Byte},
			{key="P1", default=26, min=0, max=127, type=Byte},
			{key="Noise Mix", default=33, min=0, max=127, type=Byte},
			{key="BendTime", default=65, min=0, max=127, type=Byte},
			{key="Click Freq", default=66, min=0, max=127, type=Byte},
			{key="Click Reso", default=29, min=0, max=127, type=Byte},
			{key="Attack", default=25, min=0, max=127, type=Byte},
	}
}


SynthTom={
	module_type = Generator,
	properties={
			{key="Level", default=100, min=0, max=127, type=Byte},
			{key="Pitch", default=-21, min=-64, max=63, type=Byte},
			{key="BendAmt", default=69, min=0, max=127, type=Byte},
			{key="Decay", default=67, min=0, max=127, type=Byte},
			{key="Click", default=67, min=0, max=127, type=Byte},
			{key="NoiseTone", default=83, min=0, max=127, type=Byte},
			{key="NoiseDecay", default=67, min=0, max=127, type=Byte},
			{key="P1", default=69, min=0, max=127, type=Byte},
			{key="BendTime", default=67, min=0, max=127, type=Byte},
	}
}

Tone={
	module_type = SupportGenerator,
	properties={
			{key="Level", default=100, min=0, max=127, type=Byte},
			{key="P1", default=64, min=0, max=127, type=Byte},
			{key="Bend", default=0, min=0, max=127, type=Byte},
			{key="BendDec", default=25, min=0, max=127, type=Byte},
			{key="Shape", default=67, min=0, max=127, type=Byte},
			{key="P2", default=37, min=0, max=127, type=Byte},
			{key="Attack", default=20, min=0, max=127, type=Byte},
	}
}

TransShaper={
	module_type = DualMonoEffect,
	properties={
			{key="Drive", default=64, min=0, max=127, type=Byte},
	}
}




Compressor={
	module_type = DualMonoEffect,
	properties={
			{key="MakeUp", default=25, min=0, max=127, type=Byte},
			{key="P2", default=67, min=0, max=127, type=Byte},
			{key="P1", default=67, min=0, max=127, type=Byte},
			{key="Drive", default=29, min=0, max=127, type=Byte},
	}
}


Filter={
	module_type = DualMonoEffect,
	properties={
			{key="P1", default=67, min=0, max=127, type=Byte},
			{key="P2", default=70, min=0, max=127, type=Byte},
			{key="Mode", default=0, min=0, max=2, type=Byte},
			{key="Amount", default=64, min=0, max=127, type=Byte},
			{key="Decay", default=74, min=0, max=127, type=Byte},
	}
}


Noise={
	module_type = SupportGenerator,
	properties={
			{key="P1", default=66, min=0, max=127, type=Byte},
			{key="P2", default=80, min=0, max=127, type=Byte},
			{key="Level", default=96, min=0, max=127, type=Byte},
			{key="Click", default=60, min=0, max=127, type=Byte},
			{key="Reso", default=11, min=0, max=127, type=Byte},
			{key="Sweep", default=37, min=0, max=127, type=Byte},
			{key="Attack", default=0, min=0, max=127, type=Byte},
	}
}


ParEQ={
	module_type = DualMonoEffect,
	properties={
			{key="P1", default=64, min=0, max=127, type=Byte},
			{key="P2", default=65, min=0, max=127, type=Byte},
			{key="Q", default=45, min=0, max=127, type=Byte},
	}
}


Rattler={
	module_type = DualMonoEffect,
	properties={
			{key="P1", default=64, min=0, max=127, type=Byte},
			{key="Tension", default=12, min=0, max=127, type=Byte},
			{key="Decay", default=72, min=0, max=127, type=Byte},
			{key="Tune", default=66, min=0, max=127, type=Byte},
			{key="P2", default=100, min=0, max=127, type=Byte},
	}
}


RingMod={
	module_type = DualMonoEffect,
	properties={
			{key="P1", default=25, min=0, max=127, type=Byte},
			{key="P2", default=124, min=0, max=127, type=Byte},
			{key="Decay", default=64, min=0, max=127, type=Byte},
			{key="-FreqEnv+", default=0, min=-64, max=63, type=Byte},
	}
}

TapeEcho={
	module_type = DualMonoEffect,
	properties={
			{key="P1", default=64, min=0, max=127, type=Byte},
			{key="P2", default=0, min=0, max=127, type=Byte},
			{key="Freq", default=46, min=0, max=127, type=Byte},
			{key="Reso", default=34, min=0, max=127, type=Byte},
			{key="Wobble", default=52, min=0, max=127, type=Byte},
			{key="Dry/Wet", default=24, min=0, max=127, type=Byte},
	}
}




