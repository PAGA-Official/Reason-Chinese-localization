The include files here are duplicated in ph-skia repo.

This is BAD. They must be kept in sync or bad things will happen.

We should fix this.
