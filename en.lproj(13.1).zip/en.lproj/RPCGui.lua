rpc_skin = {
	--[[
		How to define a bitmap:
		name = {
			type = kBitmap,					(required)
			resource = "ResourceFile",		(required, can be either the name of a file in the RPC folder or an absolute RPCP path)
			frames = 1,						(optional, defaults to 1)
			margins = {0, 2, 1, -1},		(optional, defaults to {0,0,0,0}, means {left, top, right, bottom} margins for hit rects and automation rects)
		},
	]]

	master_level_knob = { type = kBitmap, resource = "Bitmaps/KongVolumeKnob", frames = 64, margins = {1, 0, -10, -10} },
	note_on_led = { type = kBitmap, resource = "Bitmaps/KongNoteOn", frames = 2 },
	pitch_mod_wheel = { type = kBitmap, resource = "Bitmaps/KongWheel", frames = 64, margins = {0, 0, -7, -10} },
	qe_on_button = { type = kBitmap, resource = "Bitmaps/KongQuickEditButton", frames = 4 },
	lcd_knob = { type = kBitmap, resource = "Bitmaps/KongLCDKnob", frames = 63, margins = {3, 3, -6, -6} },
	lcd_big_knob = { type = kBitmap, resource = "Bitmaps/KongBigLCDKnob", frames = 64, margins = {8, 8, -15, -15} },
	small_dark_knob = { type = kBitmap, resource = "Bitmaps/KongSmallDarkKnob", frames = 64, margins = {0, 0, -1, -1} },
	small_light_knob = { type = kBitmap, resource = "Bitmaps/KongSmallLightKnob", frames = 64, margins = {0, 0, -1, -1} },
	module_on_button = { type = kBitmap, resource = "Bitmaps/KongModuleOn", frames = 4 },
	pad_layer_1 = { type = kBitmap, resource = "Bitmaps/KongSynth1", frames = 4 },
	pad_layer_2 = { type = kBitmap, resource = "Bitmaps/KongSynth2", frames = 4 },
	pad_layer_3 = { type = kBitmap, resource = "Bitmaps/KongSynth3", frames = 4 },
	pad_layer_4 = { type = kBitmap, resource = "Bitmaps/KongSynth4", frames = 4 }, 
	pad_layer_5 = { type = kBitmap, resource = "Bitmaps/KongSynth5", frames = 4 },
	pad_layer_6 = { type = kBitmap, resource = "Bitmaps/KongSynth6", frames = 4 },
	pad_layer_7 = { type = kBitmap, resource = "Bitmaps/KongSynth7", frames = 4 },
	pad_layer_8 = { type = kBitmap, resource = "Bitmaps/KongSynth8", frames = 4 },
	pad_layer_9 = { type = kBitmap, resource = "Bitmaps/KongSynth9", frames = 4 },
	pad_layer_10 = { type = kBitmap, resource = "Bitmaps/KongSynth10", frames = 4 },
	pad_layer_11 = { type = kBitmap, resource = "Bitmaps/KongSynth11", frames = 4 },
	pad_layer_12 = { type = kBitmap, resource = "Bitmaps/KongSynth12", frames = 4 },
	pad_layer_13 = { type = kBitmap, resource = "Bitmaps/KongSynth13", frames = 4 },
	pad_layer_14 = { type = kBitmap, resource = "Bitmaps/KongSynth14", frames = 4 },
	pad_layer_15 = { type = kBitmap, resource = "Bitmaps/KongSynth15", frames = 4 },
	pad_layer_16 = { type = kBitmap, resource = "Bitmaps/KongSynth16", frames = 4 },
	pad_hit_1 = { type = kBitmap, resource = "Bitmaps/KongHitI", frames = 4 },
	pad_hit_2 = { type = kBitmap, resource = "Bitmaps/KongHitII", frames = 4 },
	pad_hit_3 = { type = kBitmap, resource = "Bitmaps/KongHitIII", frames = 4 },
	pad_hit_4 = { type = kBitmap, resource = "Bitmaps/KongHitIV", frames = 4 },
	pad_group_a = { type = kBitmap, resource = "Bitmaps/KongPadGroupA", frames = 4 },
	pad_group_b = { type = kBitmap, resource = "Bitmaps/KongPadGroupB", frames = 4 },
	pad_group_c = { type = kBitmap, resource = "Bitmaps/KongPadGroupC", frames = 4 },
	pad_group_d = { type = kBitmap, resource = "Bitmaps/KongPadGroupD", frames = 4 },
	pad_group_e = { type = kBitmap, resource = "Bitmaps/KongPadGroupE", frames = 4 },
	pad_group_f = { type = kBitmap, resource = "Bitmaps/KongPadGroupF", frames = 4 },
	pad_group_g = { type = kBitmap, resource = "Bitmaps/KongPadGroupG", frames = 4 },
	pad_group_h = { type = kBitmap, resource = "Bitmaps/KongPadGroupH", frames = 4 },
	pad_group_i = { type = kBitmap, resource = "Bitmaps/KongPadGroupI", frames = 4 },
	vertical_meter = { type = kBitmap, resource = "Bitmaps/KongVerticalMeter" },
	horizontal_meter = { type = kBitmap, resource = "Bitmaps/KongHorizontalMeter" },
	show_drum_and_fx_button = { type = kBitmap, resource = "Bitmaps/KongFoldout", frames = 4 },
}

--[[
	How to define different kinds of controls:
		(A little hint: Refer to the C++ constructors of these classes to understand the meaning of parenthesed text below)
		
	Each control requires a position, type and property binding:
		pos = {100, 200},	(the control will be layed out at this position RELATIVE to the panel it belongs to)
		type = (one of the control types below),
		property = {
			key = "PropertyKey",	(required, is the same as the key defined when creating a property)
			group = kGlobalGroup,	(optional, defaults to "the group of the panel" passed in when parsing the script. Normally not used. 
									 Can be kGlobalGroup, kDrumLayerGroup, kPadGroup, kGeneratorGroup, kFX1Group,
									        kFX2Group, kMasterFXGroup, kGlobalFXGroup, kPanelGroup)
			index = 0,				(optional, defaults to "the index of the panel" passed in when parsing the script. Normally not used.)
		},
		
	Control types:
		The following control types are allowed. They sometimes require extra parameters to be specified except for pos, type and property.
		
		kKnob (CPropertyBitmapKnobView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = bitmapSequence)
			resolution = 64,			(optional, defaults to bitmap.frames, = inBaseResolution)
			
		kZeroSnapKnob (CPropertyZeroSnapBitmapKnobView):
			(same parameters as kKnob)
		
		kVerticalFader (CPropertyBitmapFaderView with vertical orientation):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = indicator)
			slide_bitmap = rpc_skin.name,	(optional, reference a bitmap table from the skin above, = slide)
			inverted = false,			(optional, defaults to false, = inverted)
			
		kHorizontalFader (CPropertyBitmapFaderView with horizontal orientation):
			(same parameters as kVerticalFader)
		
		kPushButton (CPropertyBitmapPushButtonView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = bitmapSequence)
			
		kCheckButton (CPropertyBitmapCheckButtonView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = bitmapSequence)
			inverted = false,			(optional, defaults to false, = inverted)
			
		kRadioButton (CPropertyBitmapRadioButtonView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = bitmapSequence)
			index = 0,					(required, = valueIndex)
			
		kRadioStepButton (CPropertyRadioStepButtonView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = inButtonBitmap)
			
		kVerticalRadioStepLED (CPropertyRadioStepLEDView with vertical orientation):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = inLEDBitmap)
			item_length = 30,			(optional, defaults to 30, = inInitialItemLength)
			
		kHorizontalRadioStepLED (CPropertyRadioStepLEDView with horizontal orientation):
			(same parameters as kVerticalRadioStepLED)
			
		kLED (CPropertyLEDView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = iBitmapSequence)
			
		kLEDNumber (CPropertyLEDNumberView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = digitsBitmapSequence)
			resolution = 64,			(optional, defaults to 64, = inPixelResolution)
			digits = 2,					(optional, defaults to 2, = inDigitCount)
			
		kUpDownButton (CPropertyUpDownBitmapButtonView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = buttonsBitmapSequence)
			repeats_per_sec = 20,		(optional, defaults to 20, = inRepeatsPerSecond)
			
		kPitchWheel (CPropertyPitchWheelView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = bitmapSequence)
			resolution = 32,			(optional, defaults to bitmap.frames, = inBaseResolution)
			
		kVerticalMeter (CPropertyVerticalMeterView):
			bitmap = rpc_skin.name,		(required, reference a bitmap table from the skin above, = inBitmapID)
			segments = 8,				(required, = inSegmentCount)
			
		kHorizontalMeter (CPropertyHorizontalMeterView);
			(same parameters as kVerticalMeter)
]]

panel_front = {
	widgets = {
		{ pos = { 38, 61 }, type = kPitchWheel, property = { key = "Pitch Bend" }, bitmap = rpc_skin.pitch_mod_wheel },
		{ pos = { 63, 61 }, type = kKnob, property = { key = "Modulation Wheel" }, bitmap = rpc_skin.pitch_mod_wheel },
		{ pos = { 627, 24 }, type = kKnob, property = { key = "Master Level" }, bitmap = rpc_skin.master_level_knob },
		{ pos = { 41, 39 }, type = kLED, property = { key = "Note On Indicator" }, bitmap = rpc_skin.note_on_led },
		{ pos = { 694, 30 }, type = kVerticalMeter, property = { key = "Master Level Output Left" }, segments = 5, bitmap = rpc_skin.vertical_meter },
		{ pos = { 705, 30 }, type = kVerticalMeter, property = { key = "Master Level Output Right" }, segments = 5, bitmap = rpc_skin.vertical_meter },
		{ pos = { 680, 364 }, type = kHorizontalMeter, property = { key = "Master FX Peak Meter" }, segments = 5, bitmap = rpc_skin.horizontal_meter },
		{ pos = { 592, 364 }, type = kHorizontalMeter, property = { key = "Bus FX Peak Meter" }, segments = 5, bitmap = rpc_skin.horizontal_meter },
		{ pos = { 601, 594 }, type = kKnob, property = { key = "Bus FX Level" }, bitmap = rpc_skin.small_light_knob },
		{ pos = { 549, 363 }, type = kCheckButton, property = { key = "Bus FX On" }, bitmap = rpc_skin.module_on_button },
		{ pos = { 637, 363 }, type = kCheckButton, property = { key = "Master FX On" }, bitmap = rpc_skin.module_on_button },
		{ pos = { 40, 323 }, type = kCheckButton, property = { key = "Show Drum And FX", group = kPanelGroup }, bitmap = rpc_skin.show_drum_and_fx_button },
		
		{ pos = { 66, 300 }, type = kCheckButton, property = { key = "QE Drum Pitch/Decay Offset", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		{ pos = { 137, 300 }, type = kCheckButton, property = { key = "QE Drum Send", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		{ pos = { 177, 300 }, type = kCheckButton, property = { key = "QE Drum Pan/Level", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		{ pos = { 244, 300 }, type = kCheckButton, property = { key = "QE Drum Tone/Level", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		
		{ pos = { 705, 109 }, type = kCheckButton, property = { key = "QE Pad Mute/Solo", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		{ pos = { 705, 169 }, type = kCheckButton, property = { key = "QE Pad Group", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		{ pos = { 705, 245 }, type = kCheckButton, property = { key = "QE Pad Drum Assignment", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
		{ pos = { 705, 312 }, type = kCheckButton, property = { key = "QE Pad Hit Assignment", group = kPanelGroup }, bitmap = rpc_skin.qe_on_button },
	},
	layouts = {
		{ pos = { 21, 46 }, control = "DeviceNameView" },
		{ pos = { 39, 18 }, size = { 175, 12 }, control = "PatchNameView" },
		{ pos = { 217, 14 }, control = "PatchBrowseButtons" },
		{ pos = { 53, 363 }, control = "DrumLayer1GenModuleTypeSelector" },
		{ pos = { 372, 363 }, control = "DrumLayer1GenFX1ModuleTypeSelector" },
		{ pos = { 460, 363 }, control = "DrumLayer1GenFX2ModuleTypeSelector" },
		{ pos = { 567, 363 }, control = "FX1ModuleTypeSelector" },
		{ pos = { 655, 363 }, control = "MasterFXModuleTypeSelector" },
		{ pos = { 55, 195 }, size = { 142, 12 }, control = "DrumLayerPatchNameView" },
		{ pos = { 44, 163 }, control = "DrumLayerPatchBrowseButtons" },
		{ pos = { 100, 163 }, control = "DrumLayerSamplingButton" },
		{ pos = { 211, 203 }, control = "DrumLayerNumberView" },
		{ pos = { 272, 3 }, size = { 342, 343 }, control = "Quick Edit Frame" },
		{ pos = { 272, 5 }, size = { 342, 15 }, control = "Quick Edit Frame Title" },
		{ pos = { 272, 327 }, size = { 342, 15 }, control = "Quick Edit Frame X Label" },
		{ pos = { 271, 3 }, size = { 15, 343 }, control = "Quick Edit Frame Y Label" },
	},
}
for y=0,3 do
	for x=0,3 do
		local t = { pos = { 291 + x * 76, 252 - y * 77 }, control = "Pad "..tostring(y*4+x+1) }
		table.insert(panel_front.layouts, t)
		local tl = { pos = { 307 + x * 76, 254 - y * 77 + 65 }, size = { 58, 10 }, control = "Pad Label "..tostring(y*4+x+1) }
		table.insert(panel_front.layouts, tl)
	end
end

panel_back = {
	widgets = {
		{ pos = { 88, 313 }, type = kCheckButton, property = { key = "Show Drum And FX", group = kPanelGroup }, bitmap = rpc_skin.show_drum_and_fx_button },
	},
	layouts = {
		{ pos = { 47, 46 }, control = "DeviceNameView" },
		{ pos = { 552, 296 }, control = "CableHole" },
	
		{ pos = { 114, 104 }, control = "CISeqControlGate" },
		{ pos = { 150, 104 }, control = "CISeqControlCV" },

		{ pos = { 100, 163 }, control = "CITrimMasterLevel" },
		{ pos = { 126, 166 }, control = "CIMasterLevel" },
		{ pos = { 100, 186 }, control = "CITrimPitchWheel" },
		{ pos = { 126, 189 }, control = "CIPitchWheel" },
		{ pos = { 100, 209 }, control = "CITrimModWheel" },
		{ pos = { 126, 212 }, control = "CIModWheel" },

		{ pos = { 593, 253 }, control = "AOMainLeft1" },
		{ pos = { 621, 253 }, control = "AOMainRight1" },
		{ pos = { 628, 76 }, control = "AOMainLeft2" },
		{ pos = { 656, 76 }, control = "AOMainRight2" },
		{ pos = { 560, 114 }, control = "AOMainLeft3" },
		{ pos = { 588, 114 }, control = "AOMainRight3" },
		{ pos = { 628, 114 }, control = "AOMainLeft4" },
		{ pos = { 656, 114 }, control = "AOMainRight4" },
		{ pos = { 560, 152 }, control = "AOMainLeft5" },
		{ pos = { 588, 152 }, control = "AOMainRight5" },
		{ pos = { 628, 152 }, control = "AOMainLeft6" },
		{ pos = { 656, 152 }, control = "AOMainRight6" },
		{ pos = { 560, 190 }, control = "AOMainLeft7" },
		{ pos = { 588, 190 }, control = "AOMainRight7" },
		{ pos = { 628, 190 }, control = "AOMainLeft8" },
		{ pos = { 656, 190 }, control = "AOMainRight8" },

		{ pos = { 83, 265 }, control = "AOSend1Left" },
		{ pos = { 110, 265 }, control = "AOSend1Right" },
		{ pos = { 151, 265 }, control = "AOSend2Left" },
		{ pos = { 178, 265 }, control = "AOSend2Right" },

		{ pos = { 422, 471 }, control = "AIFromExternalFXLeft" },
		{ pos = { 450, 471 }, control = "AIFromExternalFXRight" },

		{ pos = { 169, 459 }, control = "CITrimFXParam1" },
		{ pos = { 193, 462 }, control = "CIFXParam1" },
		{ pos = { 169, 498 }, control = "CITrimFXParam2" },
		{ pos = { 193, 501 }, control = "CIFXParam2" },

		{ pos = { 321, 471 }, control = "AOToExternalFXLeft" },
		{ pos = { 350, 471 }, control = "AOToExternalFXRight" },

		{ pos = { 78, 471 }, control = "AIBusFXLeft" },
		{ pos = { 106, 471 }, control = "AIBusFXRight" },

		{ pos = { 527, 459 }, control = "CITrimMasterFXParam1" },
		{ pos = { 551, 462 }, control = "CIMasterFXParam1" },
		{ pos = { 527, 498 }, control = "CITrimMasterFXParam2" },
		{ pos = { 551, 501 }, control = "CIMasterFXParam2" },
	},
}

for y=0,3 do
	for x=0,3 do
--		local t1 = { pos = { 257 + x * 72, 269 - y * 80 }, control = "CIPad"..tostring(y*4+x+1).."PitchCV" }
--		table.insert(panel_back.layouts, t1)
		local t2 = { pos = { 256 + x * 72, 271 - y * 72 }, control = "CIPad"..tostring(y*4+x+1).."Gate" }
		table.insert(panel_back.layouts, t2)
		local t3 = { pos = { 256 + x * 72, 289 - y * 72 }, control = "COPad"..tostring(y*4+x+1).."Gate" }
		table.insert(panel_back.layouts, t3)
	end
end

panel_front_folded = {
	widgets = {
		{ pos = { 29, 10 }, type = kLED, property = { key = "Note On Indicator" }, bitmap = rpc_skin.note_on_led },
	},
	layouts = {
		{ pos = { 548, 8 }, control = "DeviceNameView" },
		{ pos = { 263, 10 }, size = { 175, 12 }, control = "PatchNameView" },
		{ pos = { 443, 5 }, control = "PatchBrowseButtons" },

-- ### FLK: Manually move these away when folded
		{ pos = { -10000, -10000 }, control = "DrumLayer1GenModuleTypeSelector" },
		{ pos = { -10000, -10000 }, control = "DrumLayer1GenFX1ModuleTypeSelector" },
		{ pos = { -10000, -10000 }, control = "DrumLayer1GenFX2ModuleTypeSelector" },
		{ pos = { -10000, -10000 }, control = "FX1ModuleTypeSelector" },
		{ pos = { -10000, -10000 }, control = "MasterFXModuleTypeSelector" },
		{ pos = { -10000, -10000 }, size = { 142, 12 }, control = "DrumLayerPatchNameView" },
		{ pos = { -10000, -10000 }, control = "DrumLayerPatchBrowseButtons" },
		{ pos = { -10000, -10000 }, control = "DrumLayerSamplingButton" },
		{ pos = { -10000, -10000 }, control = "DrumLayerNumberView" },
		{ pos = { -10000, -10000 }, size = { 342, 343 }, control = "Quick Edit Frame" },
		{ pos = { -10000, -10000 }, size = { 342, 15 }, control = "Quick Edit Frame Title" },
		{ pos = { -10000, -10000 }, size = { 342, 15 }, control = "Quick Edit Frame X Label" },
		{ pos = { -10000, -10000 }, size = { 15, 343 }, control = "Quick Edit Frame Y Label" },

	},
}
-- ### FLK: Manually move these away when folded
for y=0,3 do
	for x=0,3 do
		local t = { pos = { -10000, -10000 }, control = "Pad "..tostring(y*4+x+1) }
		table.insert(panel_front_folded.layouts, t)
		local tl = { pos = { -10000, -10000 }, size = { 58, 10 }, control = "Pad Label "..tostring(y*4+x+1) }
		table.insert(panel_front_folded.layouts, tl)
	end
end

panel_back_folded = {
	layouts = {
		{ pos = { 548, 8 }, control = "DeviceNameView" },
		{ pos = { 317, 10 }, control = "CableHole" },
		
-- ### MG: Manually move these away when folded. Fixes Case 114976.
		{ pos = { -10000, -10000 }, control = "CISeqControlGate" },
		{ pos = { -10000, -10000 }, control = "CISeqControlCV" },

		{ pos = { -10000, -10000 }, control = "CITrimMasterLevel" },
		{ pos = { -10000, -10000 }, control = "CIMasterLevel" },
		{ pos = { -10000, -10000 }, control = "CITrimPitchWheel" },
		{ pos = { -10000, -10000 }, control = "CIPitchWheel" },
		{ pos = { -10000, -10000 }, control = "CITrimModWheel" },
		{ pos = { -10000, -10000 }, control = "CIModWheel" },

		{ pos = { -10000, -10000 }, control = "AOMainLeft1" },
		{ pos = { -10000, -10000 }, control = "AOMainRight1" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft2" },
		{ pos = { -10000, -10000 }, control = "AOMainRight2" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft3" },
		{ pos = { -10000, -10000 }, control = "AOMainRight3" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft4" },
		{ pos = { -10000, -10000 }, control = "AOMainRight4" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft5" },
		{ pos = { -10000, -10000 }, control = "AOMainRight5" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft6" },
		{ pos = { -10000, -10000 }, control = "AOMainRight6" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft7" },
		{ pos = { -10000, -10000 }, control = "AOMainRight7" },
		{ pos = { -10000, -10000 }, control = "AOMainLeft8" },
		{ pos = { -10000, -10000 }, control = "AOMainRight8" },

		{ pos = { -10000, -10000 }, control = "AOSend1Left" },
		{ pos = { -10000, -10000 }, control = "AOSend1Right" },
		{ pos = { -10000, -10000 }, control = "AOSend2Left" },
		{ pos = { -10000, -10000 }, control = "AOSend2Right" },

		{ pos = { -10000, -10000 }, control = "AIFromExternalFXLeft" },
		{ pos = { -10000, -10000 }, control = "AIFromExternalFXRight" },

		{ pos = { -10000, -10000 }, control = "CITrimFXParam1" },
		{ pos = { -10000, -10000 }, control = "CIFXParam1" },
		{ pos = { -10000, -10000 }, control = "CITrimFXParam2" },
		{ pos = { -10000, -10000 }, control = "CIFXParam2" },

		{ pos = { -10000, -10000 }, control = "AOToExternalFXLeft" },
		{ pos = { -10000, -10000 }, control = "AOToExternalFXRight" },

		{ pos = { -10000, -10000 }, control = "AIBusFXLeft" },
		{ pos = { -10000, -10000 }, control = "AIBusFXRight" },

		{ pos = { -10000, -10000 }, control = "CITrimMasterFXParam1" },
		{ pos = { -10000, -10000 }, control = "CIMasterFXParam1" },
		{ pos = { -10000, -10000 }, control = "CITrimMasterFXParam2" },
		{ pos = { -10000, -10000 }, control = "CIMasterFXParam2" },
	},
}

-- ### MG: Manually move these away when folded. Fixes Case 114976.
for y = 0, 3 do
	for x = 0, 3 do
		local t1 = { pos = { -10000, -10000 }, control = "CIPad" .. tostring(y * 4 + x + 1) .. "Gate" }
		table.insert(panel_back_folded.layouts, t1)
		local t2 = { pos = { -10000, -10000 }, control = "COPad" .. tostring(y * 4 + x + 1) .. "Gate" }
		table.insert(panel_back_folded.layouts, t2)
	end
end


module_panels = {
	layouts = {
		{ pos = { 34, 362 }, size = { 318, 229 }, control = "MainGeneratorPanel" },
		{ pos = { 353, 362 }, size = { 87, 229 }, control = "GeneratorFX1Panel" },
		{ pos = { 441, 362 }, size = { 87, 229 }, control = "GeneratorFX2Panel" },
		{ pos = { 548, 362 }, size = { 87, 229 }, control = "GlobalFXPanel" },
		{ pos = { 636, 362 }, size = { 87, 229 }, control = "MasterFXPanel" },
	}
}

drumlayer = {
	widgets = {
		{ pos = { 163, 258 }, type = kKnob, property = { key = "Tone" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 196, 232 }, type = kKnob, property = { key = "Level" }, bitmap = rpc_skin.lcd_big_knob },
		{ pos = { 163, 224 }, type = kKnob, property = { key = "Pan" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 92, 258 }, type = kKnob, property = { key = "Send FX 1" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 123, 258 }, type = kKnob, property = { key = "Send FX 2" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 92, 224 }, type = kKnob, property = { key = "Send Bus FX" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 164, 594 }, type = kKnob, property = { key = "Pitch Bend Range" }, bitmap = rpc_skin.small_dark_knob },
		{ pos = { 52, 224 }, type = kKnob, property = { key = "Pitch Offset" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 52, 258 }, type = kKnob, property = { key = "Decay Offset" }, bitmap = rpc_skin.lcd_knob },
		{ pos = { 35, 363 }, type = kCheckButton, property = { key = "Generator On" }, bitmap = rpc_skin.module_on_button },
		{ pos = { 354, 363 }, type = kCheckButton, property = { key = "FX Gen 1 On" }, bitmap = rpc_skin.module_on_button },
		{ pos = { 442, 363 }, type = kCheckButton, property = { key = "FX Gen 2 On" }, bitmap = rpc_skin.module_on_button },
		
		-- Only shown when FX1 is a support generator
		{ pos = { 363, 379 }, type = kCheckButton, property = { key = "FX1 Enable Hit 1" }, bitmap = rpc_skin.pad_hit_1 },
		{ pos = { 363, 391 }, type = kCheckButton, property = { key = "FX1 Enable Hit 2" }, bitmap = rpc_skin.pad_hit_2 },
		{ pos = { 363, 403 }, type = kCheckButton, property = { key = "FX1 Enable Hit 3" }, bitmap = rpc_skin.pad_hit_3 },
		{ pos = { 363, 415 }, type = kCheckButton, property = { key = "FX1 Enable Hit 4" }, bitmap = rpc_skin.pad_hit_4 },
		
		-- Only shown when FX2 is a support generator
		{ pos = { 451, 379 }, type = kCheckButton, property = { key = "FX2 Enable Hit 1" }, bitmap = rpc_skin.pad_hit_1 },
		{ pos = { 451, 391 }, type = kCheckButton, property = { key = "FX2 Enable Hit 2" }, bitmap = rpc_skin.pad_hit_2 },
		{ pos = { 451, 403 }, type = kCheckButton, property = { key = "FX2 Enable Hit 3" }, bitmap = rpc_skin.pad_hit_3 },
		{ pos = { 451, 415 }, type = kCheckButton, property = { key = "FX2 Enable Hit 4" }, bitmap = rpc_skin.pad_hit_4 },
	},
	layouts = {
		{ pos = { 396, 596 }, size = { 76, 12 }, control = "FX2 Output LCD" },
		{ pos = { 475, 597 }, control = "FX2 Output Button" },
	}
}

pad = {
	widgets = {
		{ pos = { 622, 278 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 0, bitmap = rpc_skin.pad_hit_1 },
		{ pos = { 622, 278 + 12 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 1, bitmap = rpc_skin.pad_hit_2 },
		{ pos = { 622, 278 + 2*12 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 2, bitmap = rpc_skin.pad_hit_3, box_placement = true },
		{ pos = { 622, 278 + 3*12 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 3, bitmap = rpc_skin.pad_hit_4 },
		
		{ pos = { 651, 142 }, type = kCheckButton, property = { key = "In Group 1" }, bitmap = rpc_skin.pad_group_a },
		{ pos = { 651 + 14, 142 }, type = kCheckButton, property = { key = "In Group 2" }, bitmap = rpc_skin.pad_group_b },
		{ pos = { 651 + 2*14, 142 }, type = kCheckButton, property = { key = "In Group 3" }, bitmap = rpc_skin.pad_group_c },
		{ pos = { 651, 142 + 14 }, type = kCheckButton, property = { key = "In Group 4" }, bitmap = rpc_skin.pad_group_d },
		{ pos = { 651 + 14, 142 + 14 }, type = kCheckButton, property = { key = "In Group 5" }, bitmap = rpc_skin.pad_group_e },
		{ pos = { 651 + 2*14, 142 + 14 }, type = kCheckButton, property = { key = "In Group 6" }, bitmap = rpc_skin.pad_group_f },
		{ pos = { 651, 142 + 2*14 }, type = kCheckButton, property = { key = "In Group 7" }, bitmap = rpc_skin.pad_group_g },
		{ pos = { 651 + 14, 142 + 2*14 }, type = kCheckButton, property = { key = "In Group 8" }, bitmap = rpc_skin.pad_group_h },
		{ pos = { 651 + 2*14, 142 + 2*14 }, type = kCheckButton, property = { key = "In Group 9" }, bitmap = rpc_skin.pad_group_i },
	},
	layouts = {
		{ pos = { 621, 110 }, control = "MutePadButton" },
		{ pos = { 650, 110 }, control = "MuteSoloClearButton" },
		{ pos = { 673, 110 }, control = "SoloPadButton" },

		{ pos = { 643, 278 }, size = { 60, 12 }, control = "Assigned Hit 1 Name" },
		{ pos = { 643, 278 + 12 }, size = { 60, 12 }, control = "Assigned Hit 2 Name" },
		{ pos = { 643, 278 + 2*12 }, size = { 60, 12 }, control = "Assigned Hit 3 Name" },
		{ pos = { 643, 278 + 3*12 }, size = { 60, 12 }, control = "Assigned Hit 4 Name" },
	}
}
for y=0,3 do
	for x=0,3 do
		local i = y * 4 + x
		local t = { 
			pos = { 637 + x * 14, 245 - y * 14 }, 
			type = kRadioButton, 
			property = { key = "Assigned Drum Layer" }, 
			index = i, 
			bitmap = rpc_skin["pad_layer_"..tostring(i + 1)],
			box_placement = (i == 9)
		}
		table.insert(pad.widgets, t)
	end
end


-------------------------------------------------------------------------------------
--                               Beginning of Quick Edit
-------------------------------------------------------------------------------------

rpc_qe_skin = {
	qe_pad_overlay_bottom = { type = kBitmap, resource = "Bitmaps/KongPadOverlayBottom" },
	qe_pad_overlay_sides = { type = kBitmap, resource = "Bitmaps/KongPadOverlaySides" },
	qe_pad_overlay_strips = { type = kBitmap, resource = "Bitmaps/KongPadOverlayStrips" },

	qe_pad_handle = { type = kBitmap, resource = "Bitmaps/KongPadHandle" },
	qe_pad_group_a = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupA", frames = 4 },
	qe_pad_group_b = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupB", frames = 4 },
	qe_pad_group_c = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupC", frames = 4 },
	qe_pad_group_d = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupD", frames = 4 },
	qe_pad_group_e = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupE", frames = 4 },
	qe_pad_group_f = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupF", frames = 4 },
	qe_pad_group_g = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupG", frames = 4 },
	qe_pad_group_h = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupH", frames = 4 },
	qe_pad_group_i = { type = kBitmap, resource = "Bitmaps/KongQEPadGroupI", frames = 4 },
	qe_pad_layer_1 = { type = kBitmap, resource = "Bitmaps/KongQEDrum1", frames = 4 },
	qe_pad_layer_2 = { type = kBitmap, resource = "Bitmaps/KongQEDrum2", frames = 4 },
	qe_pad_layer_3 = { type = kBitmap, resource = "Bitmaps/KongQEDrum3", frames = 4 },
	qe_pad_layer_4 = { type = kBitmap, resource = "Bitmaps/KongQEDrum4", frames = 4 },
	qe_pad_layer_5 = { type = kBitmap, resource = "Bitmaps/KongQEDrum5", frames = 4 },
	qe_pad_layer_6 = { type = kBitmap, resource = "Bitmaps/KongQEDrum6", frames = 4 },
	qe_pad_layer_7 = { type = kBitmap, resource = "Bitmaps/KongQEDrum7", frames = 4 },
	qe_pad_layer_8 = { type = kBitmap, resource = "Bitmaps/KongQEDrum8", frames = 4 },
	qe_pad_layer_9 = { type = kBitmap, resource = "Bitmaps/KongQEDrum9", frames = 4 },
	qe_pad_layer_10 = { type = kBitmap, resource = "Bitmaps/KongQEDrum10", frames = 4 },
	qe_pad_layer_11 = { type = kBitmap, resource = "Bitmaps/KongQEDrum11", frames = 4 },
	qe_pad_layer_12 = { type = kBitmap, resource = "Bitmaps/KongQEDrum12", frames = 4 },
	qe_pad_layer_13 = { type = kBitmap, resource = "Bitmaps/KongQEDrum13", frames = 4 },
	qe_pad_layer_14 = { type = kBitmap, resource = "Bitmaps/KongQEDrum14", frames = 4 },
	qe_pad_layer_15 = { type = kBitmap, resource = "Bitmaps/KongQEDrum15", frames = 4 },
	qe_pad_layer_16 = { type = kBitmap, resource = "Bitmaps/KongQEDrum16", frames = 4 },
	qe_pad_hit_1 = { type = kBitmap, resource = "Bitmaps/KongQEHitI", frames = 4 },
	qe_pad_hit_2 = { type = kBitmap, resource = "Bitmaps/KongQEHitII", frames = 4 },
	qe_pad_hit_3 = { type = kBitmap, resource = "Bitmaps/KongQEHitIII", frames = 4 },
	qe_pad_hit_4 = { type = kBitmap, resource = "Bitmaps/KongQEHitIV", frames = 4 },
	qe_pad_mute = { type = kBitmap, resource = "Bitmaps/KongQEMute", frames = 4 },
	qe_pad_solo = { type = kBitmap, resource = "Bitmaps/KongQESolo", frames = 4 },
	qe_invisible_handle = { type = kBitmap, resource = "Bitmaps/KongInvisibleHandle18x2" },
	qe_label_font = { 
		type = kFont, 
		win = {	name = "Arial", size = 8, subpixel_rendering = true, baseline_offset = 1 },
		mac = { name = "LucidaGrande", size = 8, baseline_offset = 1 },
	},
	qe_small_label_font = { 
		type = kFont, 
		win = {	name = "Arial", size = 7, subpixel_rendering = true, baseline_offset = 0 },
		mac = { name = "LucidaGrande", size = 7, baseline_offset = 0 },
	},
}

QE_MuteSolo = {
	layouts = {
		{ pos = { 8, 25 }, size = { 30, 14 }, control = "Quick Edit Mute" },
		{ pos = { 37, 25 }, size = { 30, 14 }, control = "Quick Edit Solo" },
	},
}

QE_DrumAssignment = {
	backdrop = rpc_qe_skin.qe_pad_overlay_sides,
	widgets = {
	},
}
for y=0,3 do
	for x=0,3 do
		local i = y * 4 + x
		local t = { 
			pos = { 7 + x * 15, 48 - y * 15 }, 
			type = kRadioButton, 
			property = { key = "Assigned Drum Layer" }, 
			index = i, 
			bitmap = rpc_qe_skin["qe_pad_layer_"..tostring(i + 1)],
		}
		table.insert(QE_DrumAssignment.widgets, t)
	end
end

QE_HitAssignment = {
	widgets = {
		{ pos = { 7, 25 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 0, bitmap = rpc_qe_skin.qe_pad_hit_1 },
		{ pos = { 7 + 15, 25 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 1, bitmap = rpc_qe_skin.qe_pad_hit_2 },
		{ pos = { 7 + 2*15, 25 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 2, bitmap = rpc_qe_skin.qe_pad_hit_3 },
		{ pos = { 7 + 3*15, 25 }, type = kRadioButton, property = { key = "Assigned Hit" }, index = 3, bitmap = rpc_qe_skin.qe_pad_hit_4 },
	},
}

QE_PadGroup = {
	backdrop = rpc_qe_skin.qe_pad_overlay_strips,
	widgets = {
		{ pos = { 27, 12 }, type = kCheckButton, property = { key = "In Group 1" }, bitmap = rpc_qe_skin.qe_pad_group_a },
		{ pos = { 27 + 14, 12 }, type = kCheckButton, property = { key = "In Group 2" }, bitmap = rpc_qe_skin.qe_pad_group_b },
		{ pos = { 27 + 2*14, 12 }, type = kCheckButton, property = { key = "In Group 3" }, bitmap = rpc_qe_skin.qe_pad_group_c },
		{ pos = { 27, 12 + 14 }, type = kCheckButton, property = { key = "In Group 4" }, bitmap = rpc_qe_skin.qe_pad_group_d },
		{ pos = { 27 + 14, 12 + 14 }, type = kCheckButton, property = { key = "In Group 5" }, bitmap = rpc_qe_skin.qe_pad_group_e },
		{ pos = { 27 + 2*14, 12 + 14 }, type = kCheckButton, property = { key = "In Group 6" }, bitmap = rpc_qe_skin.qe_pad_group_f },
		{ pos = { 27, 12 + 2*14 }, type = kCheckButton, property = { key = "In Group 7" }, bitmap = rpc_qe_skin.qe_pad_group_g },
		{ pos = { 27 + 14, 12 + 2*14 }, type = kCheckButton, property = { key = "In Group 8" }, bitmap = rpc_qe_skin.qe_pad_group_h },
		{ pos = { 27 + 2*14, 12 + 2*14 }, type = kCheckButton, property = { key = "In Group 9" }, bitmap = rpc_qe_skin.qe_pad_group_i },
	},
}

QE_PitchDecay = {
	backdrop = rpc_qe_skin.qe_pad_overlay_bottom,
	widgets = {
		{ pos = { 4, 4 }, size = { 67, 49 }, type = kPadControl, xproperty = { key = "Decay Offset" }, yproperty = { key = "Pitch Offset" }, bitmap = rpc_qe_skin.qe_pad_handle, line_color = {56,56,56}, show_lines = true },
		{ pos = { 1, 55 }, size = { 36, 10 }, type = kHorizontalLabel, property = { key = "Decay Offset" }, font = rpc_qe_skin.qe_small_label_font, text = "D: ^0", color = {255,255,255} },
		{ pos = { 37, 55 }, size = { 36, 10 }, type = kHorizontalLabel, property = { key = "Pitch Offset" }, font = rpc_qe_skin.qe_small_label_font, text = "P: ^0", color = {255,255,255} },
	},
}

QE_PanLevel = {
	backdrop = rpc_qe_skin.qe_pad_overlay_bottom,
	widgets = {
		{ pos = { 4, 4 }, size = { 67, 49 }, type = kPadControl, xproperty = { key = "Pan" }, yproperty = { key = "Level" }, bitmap = rpc_qe_skin.qe_pad_handle, line_color = {56,56,56}, show_lines = true },
		{ pos = { 1, 55 }, size = { 36, 10 }, type = kHorizontalLabel, property = { key = "Pan" }, font = rpc_qe_skin.qe_small_label_font, text = "P: ^0", color = {255,255,255} },
		{ pos = { 37, 55 }, size = { 36, 10 }, type = kHorizontalLabel, property = { key = "Level" }, font = rpc_qe_skin.qe_small_label_font, text = "L: ^0", color = {255,255,255} },
	},
}

QE_ToneLevel = {
	backdrop = rpc_qe_skin.qe_pad_overlay_bottom,
	widgets = {
		{ pos = { 4, 4 }, size = { 67, 49 }, type = kPadControl, xproperty = { key = "Tone" }, yproperty = { key = "Level" }, bitmap = rpc_qe_skin.qe_pad_handle, line_color = {56,56,56}, show_lines = true },
		{ pos = { 1, 55 }, size = { 36, 10 }, type = kHorizontalLabel, property = { key = "Tone" }, font = rpc_qe_skin.qe_small_label_font, text = "T: ^0", color = {255,255,255} },
		{ pos = { 37, 55 }, size = { 36, 10 }, type = kHorizontalLabel, property = { key = "Level" }, font = rpc_qe_skin.qe_small_label_font, text = "L: ^0", color = {255,255,255} },
	},
}

QE_Send = {
	backdrop = rpc_qe_skin.qe_pad_overlay_bottom,
	widgets = {
		{ pos = { 8, 7 }, size = { 18, 44 }, type = kRectFader, property = { key = "Send Bus FX" }, bitmap = rpc_qe_skin.qe_invisible_handle, border_color = {56,56,56}, fill_color = {56,56,56,128} },
		{ pos = { 8, 55 }, size = { 18, 10 }, type = kHorizontalLabel, property = { key = "Send Bus FX" }, font = rpc_qe_skin.qe_small_label_font, text = "^0", color = {255,255,255} },
		
		{ pos = { 29, 7 }, size = { 18, 44 }, type = kRectFader, property = { key = "Send FX 1" }, bitmap = rpc_qe_skin.qe_invisible_handle, border_color = {56,56,56}, fill_color = {56,56,56,128} },
		{ pos = { 29, 55 }, size = { 18, 10 }, type = kHorizontalLabel, property = { key = "Send FX 1" }, font = rpc_qe_skin.qe_small_label_font, text = "^0", color = {255,255,255} },
		
		{ pos = { 50, 7 }, size = { 18, 44 }, type = kRectFader, property = { key = "Send FX 2" }, bitmap = rpc_qe_skin.qe_invisible_handle, border_color = {56,56,56}, fill_color = {56,56,56,128} },
		{ pos = { 50, 55 }, size = { 18, 10 }, type = kHorizontalLabel, property = { key = "Send FX 2" }, font = rpc_qe_skin.qe_small_label_font, text = "^0", color = {255,255,255} },
	},
}

-------------------------------------------------------------------------------------
--                               Beginning of Modules
-------------------------------------------------------------------------------------

module_skin = {
	orange_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongOrangeGenKnob", frames = 64, margins = {4, 4, -4, -4} },
	grey_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongGreyGenKnob", frames = 64, margins = {4, 4, -4, -4} },
	blue_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongBlueGenKnob", frames = 64, margins = {4, 4, -4, -4} },
	rev_small_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongRewSmallKnob", frames = 64, margins = {0, -1, -3, -4} },
	rev_big_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongRewBigKnob", frames = 64, margins = {0, -1, -3, -5} },
	generic_small_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongGenericSmallKnob", frames = 64, margins = {0, -1, -1, -3} },
	generic_big_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongGenericBigKnob", frames = 64, margins = {0, -2, -2, -4} },
	tele_small_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongTelefunkSmallKnob", frames = 64, margins = {0, -2, -1, -3} },
	tele_big_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongTelefunkBigKnob", frames = 64, margins = {1, 0, -3, -4} },
	pm_black_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongPMBlackKnob", frames = 64, margins = {1, 0, -5, -7} },
	pm_blue_knob = { type = kBitmap, resource = "Bitmaps/Modules/KongPMBlueKnob", frames = 64, margins = {1, 0, -5, -7} },
	lp_bp_hp_fader = { type = kBitmap, resource = "Bitmaps/Modules/KongLpBpHpIndicator" },
	lp_bp_hp_slide = { type = kBitmap, resource = "Bitmaps/Modules/KongLpBpHpSlide" },
	resonator_model_led = { type = kBitmap, resource = "Bitmaps/Modules/KongOverdriveModelLED", frames = 2 },
	resonator_model_button = { type = kBitmap, resource = "Bitmaps/Modules/KongOverdriveModelButton", frames = 2 },
}

Tom={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongPMTomTomBackground" },
	widgets={
			{pos={36,60}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={286,60}, type=kKnob, property={key="Decay"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={36,220}, type=kKnob, property={key="StickLevel"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={136,60}, type=kKnob, property={key="Tune2"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={286,170}, type=kKnob, property={key="KettleMix"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Shell Level
			{pos={86,60}, type=kKnob, property={key="Tune1"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={36,169}, type=kKnob, property={key="StickTone"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={236,60}, type=kKnob, property={key="P1"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Damp
			{pos={286,120}, type=kKnob, property={key="KettleSize"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Shell Size
			{pos={286,220}, type=kKnob, property={key="Level"}, bitmap=module_skin.pm_black_knob, bottommiddle=true},
			{pos={186,60}, type=kKnob, property={key="BendAmt"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
	}
}

Ambience={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongReversBackground" },
	widgets={
			{pos={65,107}, type=kKnob, property={key="P2"}, bitmap=module_skin.rev_small_knob, bottommiddle=true}, -- Decay
			{pos={27,107}, type=kKnob, property={key="P1"}, bitmap=module_skin.rev_small_knob, bottommiddle=true}, -- Size
			{pos={27,156}, type=kKnob, property={key="Damp"}, bitmap=module_skin.rev_small_knob, bottommiddle=true},
			{pos={46,215}, type=kKnob, property={key="Dry/Wet"}, bitmap=module_skin.rev_big_knob, bottommiddle=true},
			{pos={65,156}, type=kKnob, property={key="Width"}, bitmap=module_skin.rev_small_knob, bottommiddle=true},
	}
}

SnareDrum={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongPMSnareBackground" },
	widgets={
			{pos={36,220}, type=kKnob, property={key="Mix"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Bottom Mix
			{pos={286,220}, type=kKnob, property={key="Level"}, bitmap=module_skin.pm_black_knob, bottommiddle=true},
			{pos={36,120}, type=kKnob, property={key="Snare Dist"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Snare Tension
			{pos={235,60}, type=kKnob, property={key="Decay"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={86,60}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={136,60}, type=kKnob, property={key="Tuning"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Tune
			{pos={36,170}, type=kKnob, property={key="Bottom Pitch"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={286,120}, type=kKnob, property={key="Edge Tune"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={186,60}, type=kKnob, property={key="P1"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Damp
	}
}

BassDrum={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongPMBassBackground" },
	widgets={
			{pos={36,60}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={286,60}, type=kKnob, property={key="Decay"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={36,220}, type=kKnob, property={key="ClickLevel"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Beater level
			{pos={136,60}, type=kKnob, property={key="Tune2"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={286,121}, type=kKnob, property={key="KettleMix"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Shell level
			{pos={86,60}, type=kKnob, property={key="Tune1"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
			{pos={36,120}, type=kKnob, property={key="ClickDiffuse"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Beater softness
			{pos={36,170}, type=kKnob, property={key="ClickFreq"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Beater tone
			{pos={236,60}, type=kKnob, property={key="P1"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true}, -- Damp
			{pos={286,220}, type=kKnob, property={key="Level"}, bitmap=module_skin.pm_black_knob, bottommiddle=true},
			{pos={186,60}, type=kKnob, property={key="BendAmt"}, bitmap=module_skin.pm_blue_knob, bottommiddle=true},
	},
}

Resonator={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongOverdriveBackground" },
	widgets={
			{pos={24,158}, type=kKnob, property={key="P2"}, bitmap=module_skin.orange_knob, bottommiddle=true}, -- Reso
			{pos={62,158}, type=kKnob, property={key="P1"}, bitmap=module_skin.orange_knob, bottommiddle=true}, -- Size
			{pos={43,78}, type=kKnob, property={key="Drive"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={15,173}, type=kHorizontalRadioStepLED, property={key="Preset"}, bitmap=module_skin.resonator_model_led, margin = 2, item_length = 20},
			{pos={43,213}, type=kRadioStepButton, property={key="Preset"}, bitmap=module_skin.resonator_model_button, bottommiddle=true},
	}
}

SynthBD={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongSynthBdBackground" },
	widgets={
			{pos={52,72}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={52,133}, type=kKnob, property={key="BendAmt"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={52,192}, type=kKnob, property={key="BendTime"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={122,72}, type=kKnob, property={key="P1"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={122,133}, type=kKnob, property={key="Noise Mix"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={192,72}, type=kKnob, property={key="Click Freq"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={192,133}, type=kKnob, property={key="Click Reso"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={192,192}, type=kKnob, property={key="Click Level"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={262,72}, type=kKnob, property={key="Attack"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={262,133}, type=kKnob, property={key="Decay"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={264,213}, type=kKnob, property={key="Level"}, bitmap=module_skin.generic_big_knob, bottommiddle=true},
	}
}

SynthSnare={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongSynthSdBackground" },
	widgets={
			{pos={89,72}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={89,133}, type=kKnob, property={key="Decay"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={91,213}, type=kKnob, property={key="Level"}, bitmap=module_skin.generic_big_knob, bottommiddle=true},
			{pos={159,72}, type=kKnob, property={key="HarmFreq"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={159,133}, type=kKnob, property={key="HarmDecay"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={159,192}, type=kKnob, property={key="HarmBalance"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={229,72}, type=kKnob, property={key="NoiseTone"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={229,133}, type=kKnob, property={key="P1"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={229,192}, type=kKnob, property={key="NoiseMix"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
	}
}

HiHat={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongSynthHihatBackground" },
	widgets={
			{pos={123,72}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={123,133}, type=kKnob, property={key="Decay"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={125,213}, type=kKnob, property={key="Level"}, bitmap=module_skin.generic_big_knob, bottommiddle=true},
			{pos={193,72}, type=kKnob, property={key="Click"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={193,133}, type=kKnob, property={key="Tone"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={193,192}, type=kKnob, property={key="P1"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
	}
}

SynthTom={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongSynthTomBackground" },
	widgets={
			{pos={89,72}, type=kKnob, property={key="Pitch"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={89,133}, type=kKnob, property={key="BendAmt"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={89,192}, type=kKnob, property={key="BendTime"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={159,72}, type=kKnob, property={key="Click"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={159,133}, type=kKnob, property={key="Decay"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={161,213}, type=kKnob, property={key="Level"}, bitmap=module_skin.generic_big_knob, bottommiddle=true},
			{pos={229,72}, type=kKnob, property={key="NoiseTone"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={229,133}, type=kKnob, property={key="NoiseDecay"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={229,192}, type=kKnob, property={key="P1"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
	}
}

Tone={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongToneBackground" },
	widgets={
			{pos={62,212}, type=kKnob, property={key="Level"}, bitmap=module_skin.grey_knob, bottommiddle=true},
			{pos={49,61}, type=kKnob, property={key="P1"}, bitmap=module_skin.orange_knob, bottommiddle=true}, -- Pitch
			{pos={62,172}, type=kKnob, property={key="Bend"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={24,172}, type=kKnob, property={key="BendDec"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={24,212}, type=kKnob, property={key="Shape"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={62,132}, type=kKnob, property={key="P2"}, bitmap=module_skin.blue_knob, bottommiddle=true}, -- Decay
			{pos={24,132}, type=kKnob, property={key="Attack"}, bitmap=module_skin.blue_knob, bottommiddle=true},
	}
}

TransShaper={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongTransientBackground" },
	widgets={
			{pos={44,212}, type=kKnob, property={key="Drive"}, bitmap=module_skin.tele_big_knob, bottommiddle=true},
			{pos={44,149}, type=kKnob, property={key="P2"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- - Decay +
			{pos={44,86}, type=kKnob, property={key="P1"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- - Attack +
	}
}

Compressor={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongCompressorBackground" },
	widgets={
			{pos={45,212}, type=kKnob, property={key="MakeUp"}, bitmap=module_skin.tele_big_knob, bottommiddle=true},
			{pos={64,147}, type=kKnob, property={key="P2"}, bitmap=module_skin.tele_small_knob, bottommiddle=true}, -- Release
			{pos={24,147}, type=kKnob, property={key="P1"}, bitmap=module_skin.tele_small_knob, bottommiddle=true}, -- Attack
			{pos={45,86}, type=kKnob, property={key="Drive"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- Is called Amount in UI
	}
}

Filter={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongFilterBackground" },
	widgets={
			{pos={44,86}, type=kKnob, property={key="P1"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- Freq
			{pos={28,147}, type=kKnob, property={key="P2"}, bitmap=module_skin.tele_small_knob, bottommiddle=true}, -- Reso
			{pos={60,149}, type=kVerticalFader, property={key="Mode"}, bitmap=module_skin.lp_bp_hp_fader, slide_bitmap=module_skin.lp_bp_hp_slide, inverted=true, bottommiddle=true},
			{pos={25,214}, type=kKnob, property={key="Amount"}, bitmap=module_skin.tele_small_knob, bottommiddle=true},
			{pos={63,214}, type=kKnob, property={key="Decay"}, bitmap=module_skin.tele_small_knob, bottommiddle=true},
	}
}

Noise={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongNoiseBackground" },
	widgets={
			{pos={49,61}, type=kKnob, property={key="P1"}, bitmap=module_skin.orange_knob, bottommiddle=true}, -- Pitch
			{pos={62,132}, type=kKnob, property={key="P2"}, bitmap=module_skin.blue_knob, bottommiddle=true}, -- Decay
			{pos={62,212}, type=kKnob, property={key="Level"}, bitmap=module_skin.grey_knob, bottommiddle=true},
			{pos={24,212}, type=kKnob, property={key="Click"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={24,172}, type=kKnob, property={key="Reso"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={62,172}, type=kKnob, property={key="Sweep"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={24,132}, type=kKnob, property={key="Attack"}, bitmap=module_skin.blue_knob, bottommiddle=true},
	}
}

ParEQ={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongParamEQBackground" },
	widgets={
			{pos={45,150}, type=kKnob, property={key="P1"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- -gain+
			{pos={45,87}, type=kKnob, property={key="P2"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- Freq
			{pos={45,213}, type=kKnob, property={key="Q"}, bitmap=module_skin.tele_big_knob, bottommiddle=true},
	}
}

Rattler={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongRattlerBackground" },
	widgets={
			{pos={43,212}, type=kKnob, property={key="P1"}, bitmap=module_skin.grey_knob, bottommiddle=true}, -- Level
			{pos={43,61}, type=kKnob, property={key="Tension"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={24,172}, type=kKnob, property={key="Decay"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={62,172}, type=kKnob, property={key="Tune"}, bitmap=module_skin.orange_knob, bottommiddle=true},
			{pos={43,132}, type=kKnob, property={key="P2"}, bitmap=module_skin.orange_knob, bottommiddle=true}, -- Tone
	}
}

RingMod={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongRingModBackground" },
	widgets={
			{pos={45,86}, type=kKnob, property={key="P1"}, bitmap=module_skin.tele_big_knob, bottommiddle=true}, -- Freq
			{pos={44,147}, type=kKnob, property={key="P2"}, bitmap=module_skin.tele_small_knob, bottommiddle=true}, -- Amount
			{pos={63,214}, type=kKnob, property={key="Decay"}, bitmap=module_skin.tele_small_knob, bottommiddle=true},
			{pos={25,214}, type=kKnob, property={key="-FreqEnv+"}, bitmap=module_skin.tele_small_knob, bottommiddle=true},
	}
}

TapeEcho={
	-- DO NOT UPDATE WITHOUT CAREFUL LAYOUT!
	backdrop = { type = kBitmap, resource = "Bitmaps/Modules/KongTapeEchoBackground" },
	widgets={
			{pos={44,94}, type=kKnob, property={key="P1"}, bitmap=module_skin.generic_big_knob, bottommiddle=true}, -- Time
			{pos={27,135}, type=kKnob, property={key="P2"}, bitmap=module_skin.generic_small_knob, bottommiddle=true}, -- FB
			{pos={27,183}, type=kKnob, property={key="Freq"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={63,183}, type=kKnob, property={key="Reso"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={63,135}, type=kKnob, property={key="Wobble"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
			{pos={45,228}, type=kKnob, property={key="Dry/Wet"}, bitmap=module_skin.generic_small_knob, bottommiddle=true},
	}
}

