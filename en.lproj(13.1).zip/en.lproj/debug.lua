-- set/clear breakpoint
-- trace on/off

function socketbind(host, port, backlog)
    local sock, err = socket.tcp()
    if not sock then return nil, err end
    sock:setoption("reuseaddr", true)
    local res, err = sock:bind(host, port)
    if not res then return nil, err end
    res, err = sock:listen(backlog)
    if not res then return nil, err end
    return sock
end

function debug_server()
	server = socketbind("localhost", 12345, 5)
	server:settimeout(1)
	-- loop forever waiting for clients
	while true do
		client = server:accept()
		if client ~= nil then
			client:settimeout(0.1)
			client_loop()
			client:close()
		end -- if client ~= nil then
		if remotedebug.get_quit_flag() then
			break
		end
	end
end

function client_loop()
	local line = ""
	while true do
		local temp_line, err, part_line = client:receive()
		if err=="timeout" and part_line~=nil then
			line = line .. part_line
		end
		if err==nil then
			if temp_line ~= nil then
				line = line .. temp_line
			end
			remotedebug.on_client_message(line)
			line = ""
		end
		if remotedebug.get_quit_flag() or err=="closed" then
			break
		end
		local send_message = remotedebug.get_debug_message()
		if send_message ~= "" then
			client:send(send_message)
		end
	end
end

